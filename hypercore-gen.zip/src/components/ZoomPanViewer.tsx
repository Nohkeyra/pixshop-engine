/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';

// This component is currently not used.
// If functionality is needed in the future,
// its implementation will be added here.
export const ZoomPanViewer: React.FC = () => {
  return null;
};